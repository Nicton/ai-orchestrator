---
confluence_url: https://shiptify.atlassian.net/wiki/spaces/TD/pages/632193041
source_type: confluence
---
# Управление пользователями

## Обзор

Раздел Users позволяет управлять всеми пользователями платформы Shiptify: создавать аккаунты, назначать роли, ограничивать доступ по локациям/аккаунтам, сбрасывать кеш и выполнять impersonation для отладки.

---

## Пользователи платформы (`/api/v1/users`)

### CRUD

| Метод | URL | Действие |
|---|---|---|
| `GET` | `/api/v1/users` | Список всех пользователей |
| `POST` | `/api/v1/users` | Создать пользователя |
| `GET` | `/api/v1/users/:id` | Детали пользователя |
| `PUT` | `/api/v1/users/:id` | Обновить пользователя |
| `DELETE` | `/api/v1/users/:id` | Удалить пользователя |

При создании пользователя контроллер:
- Генерирует или хэширует пароль (`bcrypt-nodejs`)
- Может создать или обновить PublicAPI-ключ
- Обрабатывает дублированные инвайты (`processDuplicatedInvites`)
- Синхронизирует контакт в SendInBlue (`createOrUpdateContact`)

---

## ACL (права доступа к модулям)

ACL — это запись типа `(user, account, module, role)`, определяющая, что пользователь может делать в рамках конкретного аккаунта.

Для шипперов создаётся `ShipperACL`, для перевозчиков — `CarrierACL`.

Пример структуры при создании нового пользователя:
1. Загружается главная дивизия аккаунта
2. Загружается основная категория
3. Bulk-создаются ACL-записи для всех модулей

### API

| Метод | URL | Действие |
|---|---|---|
| `GET` | `/api/v1/users/:user_id/acls` | Список ACL пользователя |
| `POST` | `/api/v1/users/:user_id/acls` | Создать ACL запись |
| `PUT` | `/api/v1/users/:user_id/acls/:acl_id` | Обновить ACL запись |

Параметры ACL:
- `module` — модуль платформы (`claims`, `requests`, `tracks` и др.)
- `role` — роль в модуле (например, `operator`)

---

## Доступ к локациям

Ограничение: пользователь видит только разрешённые ему локации.

| Метод | URL | Действие |
|---|---|---|
| `GET` | `/api/v1/users/:user_id/locations` | Список доступных локаций |
| `POST` | `/api/v1/users/:user_id/locations` | Добавить доступ к локации |
| `DELETE` | `/api/v1/users/:user_id/locations/:id` | Убрать доступ к локации |

---

## Доступ к нескольким аккаунтам (multi-account)

Пользователь может иметь доступ к нескольким аккаунтам — это позволяет работать в контексте разных компаний без создания нескольких учётных записей.

| Метод | URL | Действие |
|---|---|---|
| `GET` | `/api/v1/users/:user_id/accounts` | Список аккаунтов, к которым есть доступ |
| `POST` | `/api/v1/users/:user_id/accounts` | Добавить доступ к аккаунту |
| `DELETE` | `/api/v1/users/:user_id/accounts/:id` | Убрать доступ к аккаунту |

Отдельные view (standalone):
- `GET /api/v1/access-users-to-accounts` — все связи user-account
- `GET /api/v1/access-users-to-locations` — все связи user-location

---

## Сброс кеша пользователя

Полностью инвалидирует все Redis-кеш-ключи конкретного пользователя.

```
DELETE /api/v1/users/:user_id/cache
```

Используется, когда у пользователя отображаются устаревшие данные после изменения прав или конфигурации.

---

## Impersonation (loginAsUser)

Критическая superadmin-функция. Позволяет войти в платформу от имени любого пользователя без знания его пароля.

```
GET /api/v1/users/:user_id/login
```

Защищена `auth.api.requireAdmin`. Создаёт новую сессию с правами указанного пользователя.

**Используется для:** отладки проблем, воспроизведения багов, поддержки клиентов.

---

## 2FA управление (`/api/v1/two-factor-auth`)

| Метод | URL | Действие |
|---|---|---|
| `GET` | `/api/v1/two-factor-auth` | Получить профиль 2FA пользователя |
| `PUT` | `/api/v1/two-factor-auth` | Включить/выключить 2FA (`?user_id=...`) |
| `PATCH` | `/api/v1/two-factor-auth/code` | Установить confirmation code |

Использует `speakeasy` для генерации TOTP. QR-код генерируется через пакет `qrcode`.

---

## Login Events (аудит логинов)

Read-only журнал всех попыток входа на платформу с графиком по времени.

```
GET /api/v1/login-events
```

Раздел `login-events` в UI отображает ECharts-графики с динамикой.

---

## Invites (приглашения пользователей)

Управление приглашениями до момента создания реального аккаунта.

| Метод | URL | Действие |
|---|---|---|
| `GET/POST` | `/api/v1/invites` | Список / создать |
| `GET/PUT/DELETE` | `/api/v1/invites/:id` | CRUD |
| `POST` | `/api/v1/invites/:id/send` | Отправить email с приглашением |

Email доставляется через SendInBlue.

---

## Admins (администраторы Admin-App)

Управление аккаунтами внутренних сотрудников Shiptify, которые имеют доступ к Admin-App.

| Метод | URL | Действие |
|---|---|---|
| `GET/POST` | `/api/v1/admins` | Список / создать admin-пользователя |
| `GET/PUT/DELETE` | `/api/v1/admins/:id` | CRUD |

---

## Profile (профиль текущего администратора)

```
GET/PUT /api/v1/profile
```

Управление собственным профилем авторизованного администратора.

---

## 🔗 Граф-метаданные
- **id:** `admin-app.users`
- **type:** module-doc · **domain:** Admin-App · **status:** implemented
- **confluence:** 632193041 · **repo:** `admin-app/users/README.md`
- **code_refs:** TODO (заполнить при углублении)
- **modules:** Admin-App
- **references:** —
- **requirements:** см. чеклисты/RTM (source backfill — волна 7.2)

